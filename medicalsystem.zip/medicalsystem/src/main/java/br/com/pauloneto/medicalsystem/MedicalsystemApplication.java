package br.com.pauloneto.medicalsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalsystemApplication.class, args);
	}

}
