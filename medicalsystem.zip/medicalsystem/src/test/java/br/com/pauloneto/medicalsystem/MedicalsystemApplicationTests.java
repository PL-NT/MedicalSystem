package br.com.pauloneto.medicalsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
